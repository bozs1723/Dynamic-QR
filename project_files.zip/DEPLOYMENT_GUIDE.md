# 🚀 คู่มือการนำ Web App ขึ้นใช้งานจริง (Production Deployment)

ตอนนี้ Web App ของคุณรันอยู่แค่ในเครื่องคอมพิวเตอร์ของคุณ (Localhost) คนอื่นยังเข้าไม่ได้
เพื่อให้คนทั่วไปใช้งานได้จริง คุณต้องนำมันขึ้น **Cloud Server** ครับ

วิธีที่ง่ายและดีที่สุดสำหรับ Next.js คือใช้ **Vercel** (ฟรีและเร็วมาก)

---

## Step 1: เตรียมโค้ดขึ้น GitHub
1. สมัคร [GitHub](https://github.com/) (ถ้ายังไม่มี)
2. สร้าง Repository ใหม่ใน GitHub (ตั้งชื่ออะไรก็ได้ เช่น `dynamic-qr-app`)
3. เปิด **Terminal** ในโฟลเดอร์โปรเจกต์ของคุณ แล้วพิมพ์คำสั่งตามนี้:
   ```bash
   git init
   git add .
   git commit -m "First commit"
   git branch -M main
   git remote add origin https://github.com/YOUR_USERNAME/repo-name.git
   git push -u origin main
   ```
   *(อย่าลืมเปลี่ยน URL เป็นของ Repository คุณนะครับ)*

---

## Step 2: เชื่อมต่อกับ Vercel
1. ไปที่ [Vercel.com](https://vercel.com/) แล้วสมัครสมาชิก (Login ด้วย GitHub ได้เลย)
2. กดปุ่ม **"Add New..."** -> **"Project"**
3. เลือก Repository ที่คุณเพิ่งอัปโหลดไปเมื่อกี้ แล้วกด **Import**

---

## Step 3: ตั้งค่า Environment Variables (สำคัญมาก!)
ในหน้าตั้งค่าก่อนกด Deploy จะมีส่วนที่ชื่อว่า **Environment Variables**:
ให้คุณก๊อปปี้ค่าจากไฟล์ `.env.local` ในเครื่องคุณ ไปใส่ในนั้น:

| Name | Value |
|------|-------|
| `NEXT_PUBLIC_SUPABASE_URL` | (ค่า URL ของ Supabase คุณ) |
| `NEXT_PUBLIC_SUPABASE_ANON_KEY` | (ค่า Key ของ Supabase คุณ) |

*กด Add ทีละตัวนะครับ*

---

## Step 4: กด Deploy
1. กดปุ่ม **Deploy**
2. รอประมาณ 1-2 นาที...
3. **เสร็จแล้ว!** Vercel จะให้ลิงก์เว็บจริงมา (เช่น `your-app.vercel.app`)

ตอนนี้คุณสามารถส่งลิงก์นี้ให้คนทั้งโลกใช้งานได้เลยครับ! 🌍

---

## 💎 (Optional) การจดโดเมนชื่อตัวเอง
ถ้าอยากให้ดูโปร (เช่น `qr.yourname.com`)
1. ซื้อโดเมนจาก Godaddy หรือ Namecheap
2. ไปที่หน้า Settings ของโปรเจกต์ใน Vercel
3. เลือกเมนู **Domains** แล้วทำตามขั้นตอนที่ Vercel บอกได้เลยครับ (ง่ายมาก)
